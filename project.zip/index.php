<?php
include_once "includes/connect.php";

?>

<?php
include_once "includes/header.php";
include_once "includes/menu.php";
?>

<div class="container">
    <h1>Web Site</h1>
</div>

<?php include_once 'includes/footer.php'?>