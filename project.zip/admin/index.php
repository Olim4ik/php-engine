<?php
include_once "../includes/connect.php";
include_once "includes/header.php";
?>

<h1>Admin Panel</h1>

<?php include_once "includes/footer.php"; ?>





